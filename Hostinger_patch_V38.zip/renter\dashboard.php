<?php
// renter/dashboard.php - Redesigned with Unified SaaS UI
session_start();
require_once "../db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = (int) $_SESSION['user_id'];
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));

/* Fetch profile */
$stmt = mysqli_prepare($conn, "SELECT username, name, phone, whatsapp, room_no, profile_pic, must_change_password, pending_adjustment, advance_payment, advance_updated_at, fixed_rent, fixed_maintenance, rent_maint_updated_at FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

$display_name = $user['name'] ?: $user['username'];
$profile_pic = $user['profile_pic'] ?: "assets/img/default-avatar.png";
$room_no = $user['room_no'] ?? 'N/A';

/* Calculate totals */
// 1. Rent from pure 'rent' table
$stmt = mysqli_prepare($conn, "SELECT IFNULL(SUM(rent_amount),0) as total FROM rent WHERE user_id = ? AND status = 'Due'");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$r1 = mysqli_stmt_get_result($stmt);
$r1a = mysqli_fetch_assoc($r1);
$pure_rent_due = (float)($r1a['total'] ?? 0);
mysqli_stmt_close($stmt);

// 2. Electricity and Rent components from 'electricity' table
$stmt = mysqli_prepare($conn, "SELECT IFNULL(SUM(amount),0) as elec_total, IFNULL(SUM(rent_amount + maintenance + dues),0) as rent_portion_total FROM electricity WHERE user_id = ? AND status = 'Due'");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$r2 = mysqli_stmt_get_result($stmt);
$r2a = mysqli_fetch_assoc($r2);
$elec_due = (float)($r2a['elec_total'] ?? 0);
$rent_portion_due = (float)($r2a['rent_portion_total'] ?? 0);
mysqli_stmt_close($stmt);

$rent_due = $pure_rent_due + $rent_portion_due;
$unbilled_adj = (float)($user['pending_adjustment'] ?? 0);
$total_due = $elec_due + $rent_due - $unbilled_adj; // If adj is negative (remaining), it adds to total. If positive, subtracts.


/* Last payment */
$stmt = mysqli_prepare($conn, "SELECT payment_date, total_amount, month FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$lastp = mysqli_stmt_get_result($stmt);
$last_payment = mysqli_fetch_assoc($lastp);
mysqli_stmt_close($stmt);

/* Fetch Billing Lists */
// Get pure rents
$stmt = mysqli_prepare($conn, "
    SELECT r.id, r.month, r.rent_amount as amount, r.status, p.adjustment_amount, p.adjustment_type 
    FROM rent r 
    LEFT JOIN payments p ON p.bill_type = 'rent' AND p.bill_id = r.id 
    WHERE r.user_id = ? 
    ORDER BY r.id DESC LIMIT 10
");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$rent_res = mysqli_stmt_get_result($stmt);
$merged_rents = []; 
while ($row = mysqli_fetch_assoc($rent_res)) {
    $row['source'] = 'rent_table';
    $merged_rents[] = $row;
}
mysqli_stmt_close($stmt);

// Get rent portions from electricity bills (slips)
$stmt = mysqli_prepare($conn, "
    SELECT e.id, e.month, (e.rent_amount + e.maintenance + e.dues) as amount, e.status, p.adjustment_amount, p.adjustment_type 
    FROM electricity e 
    LEFT JOIN payments p ON p.bill_type = 'electricity' AND p.bill_id = e.id 
    WHERE e.user_id = ? AND (e.rent_amount > 0 OR e.maintenance > 0 OR e.dues > 0) 
    ORDER BY e.id DESC LIMIT 10
");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$elec_rent_res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($elec_rent_res)) {
    $row['source'] = 'elec_table';
    $merged_rents[] = $row;
}
mysqli_stmt_close($stmt);

// Get advance payments 
$stmt = mysqli_prepare($conn, "
    SELECT p.id, p.month, p.paid_amount as amount, 'Paid' as status, p.adjustment_amount, p.adjustment_type 
    FROM payments p 
    WHERE p.user_id = ? AND p.bill_type = 'advance'
    ORDER BY p.id DESC LIMIT 10
");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$adv_res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($adv_res)) {
    $row['source'] = 'advance';
    $merged_rents[] = $row;
}
mysqli_stmt_close($stmt);

// Sort merged_rents by ID descending to show latest first
usort($merged_rents, function($a, $b) {
    return $b['id'] - $a['id'];
});
// Limit to top 10 after merge
$merged_rents = array_slice($merged_rents, 0, 10);

// Electricity list (only the usage part)
$stmt = mysqli_prepare($conn, "
    SELECT e.id, e.month, e.units_consumed, e.amount, e.total_amount, e.status, p.adjustment_amount, p.adjustment_type 
    FROM electricity e 
    LEFT JOIN payments p ON p.bill_type = 'electricity' AND p.bill_id = e.id 
    WHERE e.user_id = ? 
    ORDER BY e.id DESC LIMIT 10
");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$elec_res = mysqli_stmt_get_result($stmt);
$elecs = []; while ($row = mysqli_fetch_assoc($elec_res)) $elecs[] = $row;
mysqli_stmt_close($stmt);

// Calculate advance paid
$stmt = mysqli_prepare($conn, "SELECT IFNULL(SUM(paid_amount), 0) as adv_paid FROM payments WHERE user_id = ? AND bill_type = 'advance'");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$adv_paid_res = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
$adv_paid = (float)$adv_paid_res['adv_paid'];
mysqli_stmt_close($stmt);

$advance_due = max(0, ($user['advance_payment'] ?? 0) - $adv_paid);

// Check for recent announcements (last 24h)
$has_new_notice = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM announcements WHERE created_at >= NOW() - INTERVAL 1 DAY")) > 0;

// Handle Rejection Dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_rejection'])) {
    $dismiss_id = (int)$_POST['dismiss_id'];
    @mysqli_query($conn, "ALTER TABLE payment_notifications ADD COLUMN is_dismissed TINYINT(1) DEFAULT 0");
    mysqli_query($conn, "UPDATE payment_notifications SET is_dismissed = 1 WHERE id = $dismiss_id AND user_id = $user_id");
    header("Location: dashboard.php");
    exit;
}

// Payment Notification Handling
$payment_success = "";
$payment_error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_payment_notif'])) {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        $payment_error = "Invalid CSRF token.";
    } else {
        $b_type = $_POST['bill_type'] ?? 'total';
        $b_id = !empty($_POST['bill_id']) ? (int)$_POST['bill_id'] : null;
        $amt = (float)$_POST['amount'];
        $tr_id = trim($_POST['transaction_id'] ?? '');

        if (empty($tr_id)) {
            $payment_error = "Please enter the Transaction ID / UTR.";
        } else {
            // Check for duplicate UTR
            $check_stmt = mysqli_prepare($conn, "SELECT id FROM payment_notifications WHERE transaction_id = ?");
            mysqli_stmt_bind_param($check_stmt, "s", $tr_id);
            mysqli_stmt_execute($check_stmt);
            $check_res = mysqli_stmt_get_result($check_stmt);
            
            if (mysqli_num_rows($check_res) > 0) {
                $payment_error = "This UTR number has already been submitted. Please check your transaction ID.";
            } else {
                // Ensure table exists (safeguard)
            mysqli_query($conn, "CREATE TABLE IF NOT EXISTS payment_notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                bill_type ENUM('rent', 'electricity', 'total', 'advance') NOT NULL,
                bill_id INT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                transaction_id VARCHAR(50) NOT NULL,
                payment_method VARCHAR(50) DEFAULT 'UPI',
                status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
                admin_note TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            $stmt = mysqli_prepare($conn, "INSERT INTO payment_notifications (user_id, bill_type, bill_id, amount, transaction_id) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "isids", $user_id, $b_type, $b_id, $amt, $tr_id);
            if (mysqli_stmt_execute($stmt)) {
                $payment_success = "Payment notification sent to Admin for verification!";
            } else {
                $payment_error = "Failed to send notification: " . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
        }
    }
}
}

function money($v) { return '₹' . number_format((float)$v, 2); }

// Reminder System Logic
$current_day = (int)date('d');
$is_late = ($current_day >= 20);
$overdue_list = [];

if ($total_due > 0) {
    // Collect months that are unpaid
    $due_q = mysqli_query($conn, "SELECT month FROM rent WHERE user_id = $user_id AND status = 'Due' UNION SELECT month FROM electricity WHERE user_id = $user_id AND status = 'Due'");
    while($dq = mysqli_fetch_assoc($due_q)) {
        $overdue_list[] = $dq['month'];
    }
}
$show_banner = ($is_late && !empty($overdue_list));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Dashboard | <?php echo HOUSE_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <!-- Immediate Theme Setter to prevent flashes -->
    <script>
        window.HOUSE_NAME = <?php echo json_encode(HOUSE_NAME); ?>;
        (function() {
            if (localStorage.getItem('theme') === 'dark') {
                document.documentElement.classList.add('dark-theme');
            }
        })();
    </script>
    
    <!-- Fonts & Icons -->
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <link rel="manifest" href="../manifest.json">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin-design-system.css?v=<?php echo time(); ?>">
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('../sw.js').then(reg => {
            console.log('SW registered');
          }).catch(err => {
            console.log('SW failed', err);
          });
        });
      }
    </script>
    <script src="../assets/js/pwa.js" defer></script>
    
    <style>
        /* Overriding some sidebar styles since renter doesn't use the sidebar component directly */
        .dashboard-grid-70 {
            display: grid;
            grid-template-columns: 1.6fr 1fr;
            gap: 24px;
            align-items: stretch !important; /* Forces panels to equal height */
        }

        .dashboard-grid-70 > div {
            display: flex;
        }

        .dashboard-grid-70 .panel {
            width: 100%;
            height: 100%;
            margin-bottom: 0;
        }

        /* Upgraded KPI Layout for Renter Dashboard */
        .renter-kpi-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: stretch;
            margin-bottom: 32px;
        }
        
        .renter-kpi-grid .kpi-card {
            flex: 1 1 calc(33.333% - 20px);
            min-width: 220px;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-bottom: 0; /* Clear default */
            background: var(--white);
            border: 1px solid var(--border);
            box-shadow: 0 4px 15px rgba(0,0,0,0.02);
            position: relative;
            overflow: hidden;
        }
        
        .renter-kpi-grid .kpi-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 25px rgba(0,0,0,0.06);
            border-color: var(--primary-purple);
        }
        
        /* Typography explicit overrides to match large box sizes */
        .renter-kpi-grid .kpi-value {
            font-size: 28px;
            font-weight: 800;
            margin-top: 14px;
            letter-spacing: -0.5px;
        }
        
        .renter-kpi-grid .kpi-label {
            font-size: 15px;
            font-weight: 500;
            color: var(--text-gray);
            margin-top: 4px;
        }

        /* Highlighting explicit icon styling is done via the kpi-icon class directly below */

        @media (max-width: 768px) {
            .header-renter {
                flex-direction: column;
                align-items: center;
                gap: 20px;
                margin-bottom: 24px;
                position: relative !important;
                top: auto !important;
                text-align: center;
            }
            .brand-renter {
                margin-bottom: 5px;
            }
            .user-profile {
                display: flex !important;
                flex-wrap: wrap !important;
                justify-content: center !important;
                gap: 10px !important;
                width: 100% !important;
                margin-top: 10px !important;
            }
            #themeToggle {
                width: 48px !important;
                height: 48px !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                border: 1px solid var(--border) !important;
                border-radius: 12px !important;
                background: var(--white) !important;
                box-shadow: var(--card-shadow) !important;
                font-size: 20px !important;
                flex-shrink: 0;
            }
            .user-profile > a {
                 flex: 1 1 calc(50% - 15px);
                 height: 48px !important;
                 display: flex !important;
                 align-items: center !important;
                 justify-content: center !important;
                 border-radius: 12px !important;
                 padding: 0 16px !important;
                 margin: 0 !important;
                 font-size: 13px !important;
                 font-weight: 700 !important;
            }
            .user-profile > a:nth-of-type(1) { flex: 1 1 calc(100% - 60px); }
            .user-profile > a:nth-of-type(4) { flex: 1 1 100%; }

            .dashboard-grid-70 { grid-template-columns: 1fr !important; gap: 20px !important; }
            .dashboard-grid-70 > div { display: block; }
            .dashboard-grid-70 .panel { margin-bottom: 0px !important; padding: 20px !important; border-radius: 20px !important; width: 100% !important; border: none !important; }
            
            /* Enhanced Card View for Tables */
            .table-responsive { overflow: visible !important; margin: 0 !important; padding: 0 !important; width: 100% !important; border: none !important; }
            
            table, thead, tbody, th, td, tr { display: block !important; width: 100% !important; border: none !important; }
            thead { display: none !important; }
            
            tbody tr {
                background: var(--white) !important;
                border: 1px solid var(--border) !important;
                border-radius: 16px !important;
                padding: 16px !important;
                margin-bottom: 16px !important;
                box-shadow: var(--card-shadow) !important;
            }

            tbody td {
                padding: 0 !important;
                border: none !important;
                margin-bottom: 12px !important;
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                font-size: 14px !important;
                text-align: right !important;
                font-weight: 500 !important;
            }

            tbody td::before {
                font-weight: 700;
                color: var(--text-gray);
                text-transform: uppercase;
                font-size: 11px;
                letter-spacing: 0.5px;
                text-align: left;
            }

            .left-col tbody td:nth-child(1)::before { content: "Month"; }
            .left-col tbody td:nth-child(2)::before { content: "Usage"; }
            .left-col tbody td:nth-child(3)::before { content: "Elec. Bill"; }
            .left-col tbody td:nth-child(4)::before { content: "Status"; }

            .right-col tbody td:nth-child(1)::before { content: "Month"; }
            .right-col tbody td:nth-child(2)::before { content: "Amount"; }
            .right-col tbody td:nth-child(3)::before { content: "Status"; }

            tbody td:first-child { 
                margin-bottom: 16px !important;
                padding-bottom: 12px !important;
                border-bottom: 1px dashed var(--border) !important;
            }

            tbody td:last-child {
                display: block !important;
                margin-bottom: 0 !important;
                margin-top: 10px !important;
                padding-top: 15px !important;
                border-top: 1px solid var(--border) !important;
            }
            tbody td:last-child::before { display: none !important; }
            
            tbody td:last-child > div {
                justify-content: center !important; 
                display: flex !important; 
                gap: 12px !important; 
                width: 100% !important;
            }

            tbody td:last-child button, tbody td:last-child a {
                flex: 1 !important;
                justify-content: center !important;
                padding: 12px !important;
                font-size: 15px !important;
                border-radius: 12px !important;
                height: 44px !important;
            }

            .kpi-grid { grid-template-columns: 1fr !important; gap: 16px !important; }
            .kpi-card { padding: 24px !important; }
            .kpi-value { font-size: 28px !important; }
            .kpi-icon { padding: 8px !important; font-size: 24px !important; }
            .renter-kpi-grid { flex-direction: column; }
            .renter-kpi-grid .kpi-card { flex: 1 1 100%; }
            
            .right-col td:nth-child(2) { align-items: flex-end; }
        }
        
        .header-renter {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 48px;
        }

        .brand-renter {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-renter i {
            background: var(--primary-purple);
            color: white;
            padding: 10px;
            border-radius: 12px;
            font-size: 24px;
        }

        .brand-renter span {
            font-weight: 800;
            font-size: 22px;
            color: var(--text-dark);
            letter-spacing: -0.5px;
        }

        @keyframes pulse {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }
    </style>
</head>
<body style="display: block;"> <!-- Overriding body:flex from design-system -->

<main class="main-renter">
    <header class="header-renter">
        <div class="brand-renter">
            <img src="../assets/img/logo.png" alt="Logo" style="width: 32px; height: 32px; border-radius: 8px; object-fit: cover;">
            <span><?php echo HOUSE_NAME; ?></span>
        </div>
        <div class="user-profile" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <i class='bx bx-moon' id="themeToggle" style="font-size: 24px; cursor: pointer; color: var(--text-gray);"></i>
            <a href="queries.php" class="btn-outline" style="padding: 10px 16px; font-size: 14px; border-color: #FCD34D; color: #B45309; position: relative;">
                <i class='bx bx-help-circle'></i> Help & Support
                <?php if ($has_new_notice): ?>
                    <span style="position: absolute; top: -5px; right: -5px; width: 10px; height: 10px; background: #EF4444; border-radius: 50%; border: 2px solid var(--white); animation: pulse 2s infinite;"></span>
                <?php endif; ?>
            </a>
            <a href="about-dev.php" class="btn-outline" style="padding: 10px 16px; font-size: 14px;"><i class='bx bx-help-circle'></i> About Dev</a>
            <a href="profile.php" class="btn-outline" style="padding: 10px 16px; font-size: 14px;">My Profile</a>
            <a href="../logout.php" class="btn-primary" style="background: #EF4444; padding: 10px 16px; font-size: 14px;">Logout</a>
        </div>
    </header>

    <?php
    // Check if welcome card should be shown (created within 7 days)
    $show_welcome_card = false;
    // ensure table exists logic doesn't crash here if it doesn't exist yet, we suppress error
    $welcome_q = @mysqli_query($conn, "SELECT sent_at FROM welcome_logs WHERE user_id = $user_id AND sent_at >= NOW() - INTERVAL 7 DAY");
    if ($welcome_q && mysqli_num_rows($welcome_q) > 0) {
        $show_welcome_card = true;
    }
    ?>
    <div class="welcome animate-up">
        <h1>Hi, <?php echo htmlspecialchars($display_name); ?></h1>
        <p><?php echo $show_welcome_card ? "Welcome!" : "Welcome back!"; ?> You are assigned to <strong style="color: var(--primary-purple);">Room <?php echo htmlspecialchars($room_no); ?></strong></p>
    </div>

    <?php if ($show_welcome_card): ?>
        <div class="animate-up" style="background: linear-gradient(135deg, #10B981, #059669); color: white; padding: 24px; border-radius: 20px; margin-bottom: 24px; box-shadow: 0 10px 20px rgba(16, 185, 129, 0.2); position: relative; overflow: hidden;">
            <div style="display: flex; align-items: flex-start; gap: 20px; z-index: 2; position: relative;">
                <div style="background: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 15px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <i class='bx bx-party' style="font-size: 32px;"></i>
                </div>
                <div style="flex: 1;">
                    <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 8px;">Welcome to <?php echo htmlspecialchars(HOUSE_NAME); ?>!</h3>
                    <p style="font-size: 14px; opacity: 0.95; margin: 0 0 12px 0;">We are thrilled to have you here. Your resident dashboard is your one-stop place to manage your tenancy digitally.</p>
                    <div style="font-size: 13px; opacity: 0.9;">
                        <strong>Quick Tips:</strong><br>
                        • Check your outstanding rent & electricity bills in the panels below.<br>
                        • You can click the "Pay Now Amount" to settle any pending dues.<br>
                        • After making a payment via UPI, enter the Transaction ID/UTR to notify the admin.<br>
                        • Need help? Use the "Help & Support" link in the top menu.
                    </div>
                </div>
                <i class='bx bx-x' style="cursor: pointer; font-size: 24px; opacity: 0.7;" onclick="this.parentElement.parentElement.style.display='none'" title="Dismiss"></i>
            </div>
            <i class='bx bxs-heart' style="position: absolute; right: -10px; bottom: -10px; font-size: 100px; opacity: 0.1;"></i>
        </div>
    <?php endif; ?>

    <?php if ($payment_success): ?>
        <div class="animate-up" style="background: #F0FDF4; color: #10B981; padding: 16px; border-radius: 12px; margin-bottom: 24px; border: 1px solid #DCFCE7;">
            <i class='bx bx-check-circle'></i> <?php echo $payment_success; ?>
        </div>
    <?php endif; ?>
    <?php if ($payment_error): ?>
        <div class="animate-up" style="background: #FEF2F2; color: #EF4444; padding: 16px; border-radius: 12px; margin-bottom: 24px; border: 1px solid #FEE2E2;">
            <i class='bx bx-error-circle'></i> <?php echo $payment_error; ?>
        </div>
    <?php endif; ?>

    <?php 
    // Ensure column exists silently before querying
    @mysqli_query($conn, "ALTER TABLE payment_notifications ADD COLUMN is_dismissed TINYINT(1) DEFAULT 0");
    
    // Show recently rejected payment notifications
    $rej_q = mysqli_query($conn, "SELECT id, transaction_id, admin_note, amount, DATE_FORMAT(created_at, '%b %d, %Y') as d_date FROM payment_notifications WHERE user_id = $user_id AND status = 'Rejected' AND IFNULL(is_dismissed, 0) = 0 ORDER BY id DESC LIMIT 3");
    if ($rej_q && mysqli_num_rows($rej_q) > 0):
        while ($rej = mysqli_fetch_assoc($rej_q)):
    ?>
        <div class="animate-up" style="background: #FEF2F2; color: #EF4444; padding: 16px; border-radius: 12px; margin-bottom: 24px; border: 1px solid #FEE2E2; position: relative;">
            <div style="position: absolute; top: 12px; right: 12px;">
                <form method="POST" style="margin: 0; padding: 0;">
                    <input type="hidden" name="dismiss_id" value="<?php echo $rej['id']; ?>">
                    <button type="submit" name="dismiss_rejection" style="background: none; border: none; cursor: pointer; color: #EF4444; opacity: 0.6; padding: 4px; display: flex; align-items: center; justify-content: center; border-radius: 50%;" onmouseover="this.style.opacity='1'; this.style.background='rgba(239, 68, 68, 0.1)'" onmouseout="this.style.opacity='0.6'; this.style.background='none'">
                        <i class='bx bx-x' style="font-size: 22px;" title="Dismiss Message"></i>
                    </button>
                </form>
            </div>

            <div style="font-weight: 700; margin-bottom: 4px; display: flex; align-items: center; gap: 6px; padding-right: 30px;">
                <i class='bx bx-x-circle' style="font-size: 18px;"></i> 
                Payment Rejected (₹<?php echo number_format($rej['amount'], 2); ?> on <?php echo $rej['d_date']; ?>)
            </div>
            <div style="font-size: 13px; margin-left: 24px;"><strong>UTR:</strong> <?php echo htmlspecialchars($rej['transaction_id']); ?></div>
            <?php if (!empty($rej['admin_note'])): ?>
            <div style="font-size: 13px; margin-top: 4px; margin-left: 24px; color: #B91C1C;">
                <strong>Reason:</strong> <?php echo htmlspecialchars($rej['admin_note']); ?>
            </div>
            <?php endif; ?>
        </div>
    <?php 
        endwhile;
    endif; 
    ?>

    <?php if ($show_banner): ?>
        <div class="animate-up" style="background: linear-gradient(135deg, #FF4B2B, #FF416C); color: white; padding: 24px; border-radius: 20px; margin-bottom: 32px; box-shadow: 0 10px 20px rgba(255, 75, 43, 0.2); display: flex; align-items: center; gap: 20px; position: relative; overflow: hidden;">
            <div style="background: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 15px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <i class='bx bxs-bell-ring bx-tada' style="font-size: 32px;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 4px;">Payment Reminder!</h3>
                <p style="font-size: 14px; opacity: 0.9; margin: 0;">It's the <?php echo date('jS'); ?> of the month. Your bills for <strong><?php echo implode(', ', array_unique($overdue_list)); ?></strong> are still pending. Please clear them to avoid service interruptions.</p>
            </div>
            <button onclick="document.querySelector('.kpi-card .btn-primary').click()" class="btn-primary" style="background: white; color: #FF4B2B; border: none; padding: 12px 20px; white-space: nowrap;">
                Pay Now
            </button>
            <i class='bx bxs-quote-right' style="position: absolute; right: -10px; bottom: -10px; font-size: 80px; opacity: 0.1;"></i>
        </div>
    <?php endif; ?>

    <div class="renter-kpi-grid animate-up">
        <div class="kpi-card hover-lift" style="border-top: 4px solid <?php echo $total_due > 0 ? '#EF4444' : '#10B981'; ?>;">
            <div class="kpi-header" style="display: flex; align-items: center; gap: 8px;">
                <i class='bx bx-credit-card kpi-icon' style="color: #624BFF !important; background: rgba(98, 75, 255, 0.15) !important;"></i>
                <div class="trend <?php echo $total_due > 0 ? 'trend-down' : 'trend-up'; ?>">
                    <i class='bx bx-info-circle'></i> <?php echo $total_due > 0 ? 'Payment Due' : 'All Clear'; ?>
                </div>
            </div>
            <div class="kpi-value" style="<?php echo $total_due > 0 ? 'color: #EF4444;' : ''; ?>"><?php echo money($total_due); ?></div>
            <div class="kpi-label">Total Outstanding</div>
            <?php if ($unbilled_adj != 0): ?>
                <div style="font-size: 11px; margin-top: 2px; font-weight: 600; color: <?php echo $unbilled_adj > 0 ? '#10B981' : '#EF4444'; ?>;">
                    <?php echo $unbilled_adj > 0 ? 'Credit: ' : 'Remaining: '; ?><?php echo money(abs($unbilled_adj)); ?> (Unbilled)
                </div>
            <?php endif; ?>
            
            <?php if($total_due > 0): ?>
                <div style="margin-top: auto; padding-top: 12px;">
                    <button onclick="openPaymentModal(<?php echo $total_due; ?>, 'Total Outstanding Balance', 'total')" class="btn-primary" style="width: 100%; justify-content: center; font-size: 13px; background: #10B981; border: none; border-radius: 12px;">
                        <i class='bx bx-qr-scan'></i> Pay Now Amount
                    </button>
                </div>
            <?php else: ?>
                <div style="margin-top: auto;"></div> <!-- For flex alignment -->
            <?php endif; ?>
        </div>
        
        <div class="kpi-card hover-lift">
            <div class="kpi-header" style="display: flex; align-items: center; gap: 8px;">
                <i class='bx bx-bolt kpi-icon' style="color: #F59E0B !important; background: rgba(245, 158, 11, 0.15) !important;"></i>
            </div>
            <div class="kpi-value"><?php echo money($elec_due); ?></div>
            <div class="kpi-label">Electricity Due</div>
            <div style="margin-top: auto;"></div>
        </div>
        
        <div class="kpi-card hover-lift">
            <div class="kpi-header" style="display: flex; align-items: center; gap: 8px;">
                <i class='bx bx-home kpi-icon' style="color: #EC4899 !important; background: rgba(236, 72, 153, 0.15) !important;"></i>
            </div>
            <div class="kpi-value"><?php echo money($rent_due); ?></div>
            <div class="kpi-label">Rent Due</div>
            <div style="margin-top: auto;"></div>
        </div>
        
        <div class="kpi-card hover-lift">
            <div class="kpi-header" style="display: flex; align-items: center; gap: 8px;">
                <i class='bx bx-check-double kpi-icon' style="color: #10B981 !important; background: rgba(16, 185, 129, 0.15) !important;"></i>
            </div>
            <div class="kpi-value" style="font-size: 18px; margin-top: 5px;"><?php echo $last_payment ? money($last_payment['total_amount']) : 'No history'; ?></div>
            <div class="kpi-label">Last Payment Made</div>
            <div style="margin-top: auto;"></div>
        </div>
        
        <div class="kpi-card hover-lift">
            <div class="kpi-header" style="display: flex; align-items: center; gap: 8px;">
                <i class='bx bx-wallet kpi-icon' style="color: #3B82F6 !important; background: rgba(59, 130, 246, 0.15) !important;"></i>
            </div>
            <div class="kpi-value" style="font-size: 24px;">
                <?php if ($advance_due > 0 && $adv_paid == 0): ?>
                    <?php echo money($user['advance_payment'] ?? 0); ?>
                <?php else: ?>
                    <?php echo money($adv_paid); ?> <span style="font-size: 14px; color: var(--text-gray); font-weight: 500;">/ <?php echo money($user['advance_payment'] ?? 0); ?></span>
                <?php endif; ?>
            </div>
            <div class="kpi-label">Advance Security</div>
            
            <?php if ($advance_due > 0): ?>
                <div style="margin-top: auto; padding-top: 12px;">
                    <button onclick="openPaymentModal(<?php echo $advance_due; ?>, 'Advance Security Deposit', 'advance')" class="btn-primary" style="width: 100%; justify-content: center; font-size: 13px; background: #3B82F6; border: none; border-radius: 12px; height: 36px; padding: 0;">
                        <i class='bx bx-qr-scan'></i> Pay Advance
                    </button>
                </div>
            <?php else: ?>
                <?php if (!empty($user['advance_updated_at'])): ?>
                    <div style="font-size: 11px; margin-top: auto; padding-top: 4px; color: var(--text-gray);">
                        Updated: <?php echo date("M d, Y", strtotime($user['advance_updated_at'])); ?>
                    </div>
                <?php else: ?>
                    <div style="margin-top: auto;"></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <?php if ($user['fixed_rent'] > 0 || $user['fixed_maintenance'] > 0): ?>
        <div class="kpi-card hover-lift">
            <div class="kpi-header" style="display: flex; align-items: center; gap: 8px;">
                <i class='bx bx-building-house kpi-icon' style="color: #8B5CF6 !important; background: rgba(139, 92, 246, 0.15) !important;"></i>
            </div>
            <div class="kpi-value" style="font-size: 18px; line-height: 1.4;">
                <span style="font-size: 13px; color: var(--text-gray); font-weight: 500;">Rent:</span> <?php echo money($user['fixed_rent'] ?? 0); ?><br>
                <span style="font-size: 13px; color: var(--text-gray); font-weight: 500;">Maint:</span> <?php echo money($user['fixed_maintenance'] ?? 0); ?>
            </div>
            <div class="kpi-label" style="margin-top: 5px;">Fixed Monthly Charges</div>
            <?php if (!empty($user['rent_maint_updated_at'])): ?>
                <div style="font-size: 11px; margin-top: auto; color: var(--text-gray); padding-top: 4px;">
                    Updated: <?php echo date("M d, Y", strtotime($user['rent_maint_updated_at'])); ?>
                </div>
            <?php else: ?>
                <div style="margin-top: auto;"></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="dashboard-grid-70 animate-up">
        <div class="left-col">
            <div class="panel">
                <div class="panel-header">
                    <h2 style="font-size: 18px; font-weight: 700;">⚡ Electricity Bill History</h2>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Usage</th>
                                <th>Elec. Bill</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($elecs)): ?>
                                <tr><td colspan="5" style="text-align: center; padding: 40px; color: var(--text-gray);">No bills found.</td></tr>
                            <?php else: foreach ($elecs as $e): ?>
                            <tr>
                                <td style="font-weight: 600; white-space: nowrap;"><?php echo htmlspecialchars($e['month']); ?></td>
                                <td><?php echo (int)$e['units_consumed']; ?> Units</td>
                                <td style="font-weight: 700;">
                                    ₹<?php echo number_format($e['amount'], 2); ?>
                                    <?php if (!empty($e['adjustment_type'])): ?>
                                        <div style="font-size: 10px; font-weight: 600; color: <?php echo $e['adjustment_type'] == 'extra' ? '#10B981' : '#EF4444'; ?>;">
                                            <?php echo $e['adjustment_type'] == 'extra' ? 'Extra' : 'Rem.'; ?>: ₹<?php echo number_format(abs($e['adjustment_amount']), 0); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge <?php echo $e['status'] == 'Paid' ? 'badge-paid' : 'badge-due'; ?>"><?php echo $e['status']; ?></span></td>
                                <td>
                                    <div style="display: flex; gap: 8px; flex-wrap: nowrap; min-width: max-content;">
                                        <a href="../admin/slip.php?elec_id=<?php echo $e['id']; ?>" class="btn-outline" style="width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 16px;" target="_blank" title="Receipt"><i class='bx bx-receipt'></i></a>
                                        <?php if($e['status'] != 'Paid'): ?>
                                            <button onclick="openPaymentModal(<?php echo $e['total_amount']; ?>, 'Full Bill (Incl. Rent) - <?php echo $e['month']; ?>', 'electricity', <?php echo $e['id']; ?>)" class="btn-outline" style="width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 16px;" title="Pay Now"><i class='bx bx-credit-card'></i></button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="right-col">
            <div class="panel">
                <div class="panel-header">
                    <h2 style="font-size: 18px; font-weight: 700;">🏠 Rent History</h2>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($merged_rents)): ?>
                                <tr><td colspan="4" style="text-align: center; padding: 40px; color: var(--text-gray);">No records.</td></tr>
                            <?php else: foreach ($merged_rents as $r): ?>
                            <tr>
                                <td style="font-weight: 600; white-space: nowrap;"><?php echo htmlspecialchars($r['month']); ?></td>
                                <td style="font-weight: 700;">
                                    ₹<?php echo number_format($r['amount'], 2); ?>
                                    <?php if (!empty($r['adjustment_type'])): ?>
                                        <div style="font-size: 10px; font-weight: 600; color: <?php echo $r['adjustment_type'] == 'extra' ? '#10B981' : '#EF4444'; ?>;">
                                            <?php echo $r['adjustment_type'] == 'extra' ? 'Extra' : 'Rem.'; ?>: ₹<?php echo number_format(abs($r['adjustment_amount']), 0); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge <?php echo $r['status'] == 'Paid' ? 'badge-paid' : 'badge-due'; ?>"><?php echo $r['status']; ?></span></td>
                                <td>
                                    <div style="display: flex; gap: 8px; flex-wrap: nowrap; min-width: max-content;">
                                        <?php if($r['source'] == 'elec_table'): ?>
                                            <a href="../admin/slip.php?elec_id=<?php echo $r['id']; ?>" class="btn-outline" style="width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 16px;" target="_blank" title="Receipt"><i class='bx bx-receipt'></i></a>
                                        <?php elseif($r['source'] == 'advance'): ?>
                                            <span style="font-size: 11px; color: var(--text-gray); font-weight: 600; background: rgba(0,0,0,0.05); padding: 4px 8px; border-radius: 8px;">Adv. Pmt</span>
                                        <?php endif; ?>
                                        
                                        <?php if($r['status'] != 'Paid' && $r['source'] != 'advance'): ?>
                                            <?php 
                                            // Determine display and payment amounts
                                            $pay_amt = $r['amount'];
                                            $pay_title = "Rent Bill - " . $r['month'];
                                            $pay_type = "rent";
                                            if ($r['source'] == 'elec_table') {
                                                // If from a slip, we must find the total_amount of that slip to pay properly
                                                $sid = $r['id'];
                                                $sq = mysqli_query($conn, "SELECT total_amount FROM electricity WHERE id = $sid");
                                                $sr = mysqli_fetch_assoc($sq);
                                                $pay_amt = $sr['total_amount'];
                                                $pay_title = "Full Bill (Incl. Elec) - " . $r['month'];
                                                $pay_type = "electricity";
                                            }
                                            ?>
                                            <button onclick="openPaymentModal(<?php echo $pay_amt; ?>, '<?php echo $pay_title; ?>', '<?php echo $pay_type; ?>', <?php echo $r['id']; ?>)" class="btn-outline" style="width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 16px;" title="Pay Now"><i class='bx bx-credit-card'></i></button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

    <!-- Intro.js for the guide -->
    <link rel="stylesheet" href="https://unpkg.com/intro.js/minified/introjs.min.css">
    <script src="https://unpkg.com/intro.js/minified/intro.min.js"></script>
    <style>
        .introjs-tooltip { 
            border-radius: 20px; 
            padding: 24px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.15); 
            border: 1px solid rgba(255,255,255,0.6);
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            color: #1E293B;
            font-family: 'Inter', system-ui, sans-serif;
            animation: introjs-pulse 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes introjs-pulse {
            0% { transform: scale(0.9) translateY(10px); opacity: 0; }
            100% { transform: scale(1) translateY(0); opacity: 1; }
        }
        .dark-theme .introjs-tooltip {
            background: rgba(30, 41, 59, 0.85);
            color: #F8FAFC;
            border-color: rgba(255,255,255,0.1);
        }
        .introjs-tooltiptext { color: inherit; font-size: 14px; line-height: 1.6; opacity: 0.9; }
        .introjs-tooltip-header { padding-bottom: 12px; }
        .introjs-tooltip-title { color: #624BFF; font-weight: 800; font-size: 18px; letter-spacing: -0.5px; }
        .dark-theme .introjs-tooltip-title { color: #A5B4FC; }
        
        .introjs-button { border-radius: 12px; text-shadow: none; box-shadow: none; font-weight: 600; padding: 10px 20px; transition: all 0.2s ease; cursor: pointer; font-size: 13px; }
        .introjs-nextbutton { background: linear-gradient(135deg, #624BFF, #5039E6); color: white; border: none; box-shadow: 0 4px 12px rgba(98, 75, 255, 0.25); }
        .introjs-nextbutton:hover { background: linear-gradient(135deg, #5039E6, #412bd4); box-shadow: 0 6px 16px rgba(98, 75, 255, 0.35); transform: translateY(-1px); color: white; }
        .introjs-prevbutton { background: transparent; color: #64748B; border: 1px solid #E2E8F0; }
        .introjs-prevbutton:hover { background: #F8FAFC; color: #1E293B; }
        .introjs-skipbutton { color: #94A3B8; font-weight: 500; }
        .dark-theme .introjs-button { border: none; }
        .dark-theme .introjs-prevbutton { background: rgba(255,255,255,0.05); color: #CBD5E1; border: 1px solid rgba(255,255,255,0.1); }
        .dark-theme .introjs-prevbutton:hover { background: rgba(255,255,255,0.1); color: #FFF; }
        .dark-theme .introjs-nextbutton { background: linear-gradient(135deg, #624BFF, #412bd4); color: white; }
        
        .introjs-bullets ul li a { background: #CBD5E1; border-radius: 6px; width: 8px; height: 8px; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
        .introjs-bullets ul li a.active { background: #624BFF; width: 24px; }
        .dark-theme .introjs-bullets ul li a { background: #475569; }
        .dark-theme .introjs-bullets ul li a.active { background: #818CF8; }
        
        .introjs-helperLayer { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px); border: 2px solid #624BFF; border-radius: 20px; box-shadow: 0 0 0 9999px rgba(15, 23, 42, 0.4); }
        .dark-theme .introjs-helperLayer { background: rgba(0, 0, 0, 0.1); border-color: #818CF8; box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.7); }
    </style>

    <!-- Payment Modal -->
    <div id="paymentModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 9999; align-items: center; justify-content: center; padding: 10px;">
        <div class="panel animate-up" style="max-width: 400px; width: 100%; text-align: center; padding: 20px; max-height: 85vh; overflow-y: auto; border-radius: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                <h2 style="font-size: 16px; font-weight: 800; color: var(--text-dark);">Make Payment</h2>
                <i class='bx bx-x' onclick="closePaymentModal()" style="font-size: 24px; cursor: pointer; color: var(--text-gray);"></i>
            </div>
            
            <div id="paymentDetails" style="margin-bottom: 16px;">
                <div id="paymentTitle" style="font-weight: 700; font-size: 14px; margin-bottom: 4px; color: var(--text-gray);">Total Outstanding Balance</div>
                <div style="font-size: 26px; font-weight: 800; color: var(--primary-purple); letter-spacing: -0.5px;">₹<span id="paymentAmountDisplay">0</span></div>
            </div>

            <div style="background: white; padding: 15px; border-radius: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); margin-bottom: 16px; border: 1px solid var(--border);">
                <div style="background: #fff; padding: 8px; border-radius: 12px; display: inline-block; margin-bottom: 10px; border: 1px solid #f0f0f0;">
                    <img id="dynamicQR" src="" alt="UPI QR Code" style="width: 150px; height: 150px; display: block;">
                </div>
                <p style="font-size: 11px; color: #64748b; font-weight: 600;">Scan with any UPI App</p>
                <div style="font-size: 12px; font-weight: 700; color: #1e293b; margin-top: 4px;">nikhil119124-1@oksbi</div>
            </div>

            <div style="background: rgba(98, 75, 255, 0.04); padding: 10px; border-radius: 12px; border: 1px solid rgba(98, 75, 255, 0.1); margin-bottom: 16px;">
                <p style="font-size: 10px; color: var(--primary-purple); font-weight: 700; text-transform: uppercase; margin-bottom: 2px;">
                    <i class='bx bx-timer'></i> Session Expires in <span id="paymentTimer">05:00</span>
                </p>
                <p style="font-size: 9px; color: var(--text-gray); line-height: 1.4;">Transfer within this time to ensure amount accuracy.</p>
            </div>

            <form method="POST" id="paymentNotifyForm" style="text-align: left; border-top: 1px solid var(--border); padding-top: 16px;">
                <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($_SESSION['csrf']); ?>">
                <input type="hidden" name="bill_type" id="hiddenBillType">
                <input type="hidden" name="bill_id" id="hiddenBillId">
                <input type="hidden" name="amount" id="hiddenAmount">
                
                <label style="font-size: 11px; font-weight: 700; color: var(--text-dark); display: block; margin-bottom: 6px;">Enter Transaction ID / UTR</label>
                <input type="text" name="transaction_id" placeholder="Enter 12-digit UTR No." required style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: 10px; margin-bottom: 12px; background: var(--bg-main); color: var(--text-dark); outline: none; font-size: 13px;">
                
                <button type="submit" id="submitPaymentBtn" name="submit_payment_notif" class="btn-primary" style="width: 100%; justify-content: center; padding: 12px; font-size: 13px;">
                    <i class='bx bx-bell'></i> Notify Admin
                </button>
            </form>

            <script>
            document.getElementById('paymentNotifyForm').addEventListener('submit', function(e) {
                let btn = document.getElementById('submitPaymentBtn');
                if (btn.disabled) {
                    e.preventDefault();
                    return;
                }
                // Don't prevent default, we want the form to submit
                setTimeout(() => {
                    btn.disabled = true;
                    btn.innerHTML = "<i class='bx bx-loader-alt bx-spin'></i> Submitting...";
                }, 10);
            });
            </script>

            <div style="border-top: 1px solid var(--border); padding-top: 15px; margin-top: 16px;">
                <p style="font-size: 11px; color: var(--text-gray); margin-bottom: 10px;">Having issues? Use the permanent scanner:</p>
                <button onclick="openScannerModal()" class="btn-outline" style="width: 100%; justify-content: center; font-size: 11px; padding: 8px;">
                    <i class='bx bx-qr-scan'></i> Open Owner's Scanner
                </button>
            </div>
        </div>
    </div>

    <!-- Owner Scanner Modal -->
    <div id="scannerModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
        <div class="panel animate-up" style="max-width: 400px; width: 100%; text-align: center; padding: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="font-size: 18px; font-weight: 800; color: var(--text-dark);">Owner's Scanner</h2>
                <i class='bx bx-x' onclick="closeScannerModal()" style="font-size: 26px; cursor: pointer; color: var(--text-gray);"></i>
            </div>
            <div style="background: white; padding: 10px; border-radius: 20px; margin-bottom: 15px;">
                <img src="../assets/img/gpay-qr.jpg" alt="Owner Scanner" style="width: 100%; border-radius: 12px; display: block;">
            </div>
            <p style="font-size: 12px; color: var(--text-gray);">Fixed GPay scanner for manual amount entry.</p>
        </div>
    </div>
</main>

    <script src="../assets/js/renter.js?v=<?php echo time(); ?>"></script>

</body>
</html>